import numpy as np
import matplotlib.pyplot as plt

zeta = float(input())  # Damping ratio (choose your value)
wn = 1.0   # Angular frequency (choose your value)
h = 0.01   # Time step size
t_max = 10.0  # Maximum time

x0 = 1.0  # Initial position
v0 = 0.0  # Initial velocity

t_values = np.arange(0, t_max, h)
x_values = []
v_values = []

# Initialize the variables
x = x0
v = v0

# Runge-Kutta method loop
for t in t_values:
    x_values.append(x)
    v_values.append(v)
    
    # Update x and v using the fourth-order Runge-Kutta method
    k1_x = h * v
    k1_v = h * (-2 * zeta * wn * v - wn**2 * x)
    
    k2_x = h * (v + 0.5 * k1_v)
    k2_v = h * (-2 * zeta * wn * (v + 0.5 * k1_v) - wn**2 * (x + 0.5 * k1_x))
    
    k3_x = h * (v + 0.5 * k2_v)
    k3_v = h * (-2 * zeta * wn * (v + 0.5 * k2_v) - wn**2 * (x + 0.5 * k2_x))
    
    k4_x = h * (v + k3_v)
    k4_v = h * (-2 * zeta * wn * (v + k3_v) - wn**2 * (x + k3_x))
    
    x += (k1_x + 2 * k2_x + 2 * k3_x + k4_x) / 6
    v += (k1_v + 2 * k2_v + 2 * k3_v + k4_v) / 6

plt.figure(figsize=(10, 5))
plt.plot(t_values, x_values, label='Position (x)')
plt.plot(t_values, v_values, label='Velocity (v)')
plt.xlabel('Time')
plt.legend()
plt.title('Runge-Kutta Method Solution')
plt.grid(True)
plt.show()

