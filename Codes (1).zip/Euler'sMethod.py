import numpy as np
import matplotlib.pyplot as plt

# Parameters
zeta = float(input( )) # Damping ratio (choose your value)
wn = 1.0   # Angular frequency (choose your value)
h = 0.01   # Time step size
t_max = 10.0  # Maximum time

# Assumptions
x0 = 1.0  # Initial position
v0 = 0.0  # Initial velocity

# Create arrays to add the updated values
t_values = np.arange(0, t_max, h)
x_values = [ ]
v_values = [ ]

# Initialization
x = x0
v = v0

# Applying Euler's method 
for t in t_values:
    x_values.append(x)
    v_values.append(v)

    # Update x and v using Euler's method
    x_new = x + h * v
    v_new = v + h * (-2 * zeta * wn * v - wn**2 * x)

    # Update x and v for the next iteration
    x = x_new
    v = v_new

plt.figure(figsize=(10, 5))
plt.plot(t_values, x_values, label='Position (x)')
plt.plot(t_values, v_values, label='Velocity (v)')
plt.xlabel('Time')
plt.legend()
plt.title('Euler\'s Method Solution')
plt.grid(True)
plt.show()


